/*
 * Copyright (c) 2015.
 *
 * Copyrighted by SmithsModding according to the project License
 */

package com.SmithsModding.Armory.Common.Knowledge.Knowledge;

public class HardKnowledge extends BasicKnowledge {
    public HardKnowledge() {
        super();

        this.iMinimalExperienceLevel = 0F;
        this.iMaximalExperienceLevel = 0.65F;

    }
}
