package com.SmithsModding.Armory.Common.TileEntity.Anvil;

import com.SmithsModding.Armory.Common.TileEntity.Core.TileEntityArmory;

/**
 * Created by Orion
 * Created on 15.05.2015
 * 13:29
 * <p/>
 * Copyrighted according to Project specific license
 */
public class TileEntityCoolingBasin extends TileEntityArmory {


    @Override
    public float getProgressBarValue(String pProgressBarID) {
        return 0;
    }
}
