package com.SmithsModding.Armory.Common.TileEntity.Core;

/**
 * Created by Orion
 * Created on 02.06.2015
 * 10:52
 * <p/>
 * Copyrighted according to Project specific license
 */
public interface ICustomInputHandler {

    void HandleCustomInput(String pInputID, String pInput);
}
