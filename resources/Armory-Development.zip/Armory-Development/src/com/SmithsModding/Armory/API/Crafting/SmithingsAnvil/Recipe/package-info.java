/**
 * Created by Orion
 * Created on 08.06.2015
 * 12:47
 * <p/>
 * Copyrighted according to Project specific license
 */
@API(owner = "Armory", apiVersion = References.General.API_VERSION, provides = "Armory-API|Crafting|SmithingsAnvil|Recipe") package com.SmithsModding.Armory.API.Crafting.SmithingsAnvil.Recipe;

import com.SmithsModding.Armory.Util.References;
import cpw.mods.fml.common.API;
