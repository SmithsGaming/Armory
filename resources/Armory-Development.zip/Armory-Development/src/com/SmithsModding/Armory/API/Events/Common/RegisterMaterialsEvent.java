package com.SmithsModding.Armory.API.Events.Common;
/*
*   RegisterMaterialsEvent (This event is used to notify other mods of moment to register their materials.)
*   Created by: Orion
*   Created on: 8-4-2014
*/

import cpw.mods.fml.common.eventhandler.Event;

public class RegisterMaterialsEvent extends Event {

    public RegisterMaterialsEvent() {
        super();
    }
}
