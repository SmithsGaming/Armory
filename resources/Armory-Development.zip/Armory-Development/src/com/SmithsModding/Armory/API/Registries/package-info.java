/**
 * Created by Orion
 * Created on 08.06.2015
 * 13:29
 * <p/>
 * Copyrighted according to Project specific license
 */
@API(owner = "Armory", apiVersion = References.General.API_VERSION, provides = "Armory-API|Registries") package com.SmithsModding.Armory.API.Registries;

import com.SmithsModding.Armory.Util.References;
import cpw.mods.fml.common.API;
