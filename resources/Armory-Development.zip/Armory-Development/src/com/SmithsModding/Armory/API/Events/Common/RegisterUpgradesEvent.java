package com.SmithsModding.Armory.API.Events.Common;
/*
*   RegisterUpgradesEvent
*   Created by: Orion
*   Created on: 8-4-2014
*/

import cpw.mods.fml.common.eventhandler.Event;

public class RegisterUpgradesEvent extends Event {
    public RegisterUpgradesEvent() {
        super();
    }
}
