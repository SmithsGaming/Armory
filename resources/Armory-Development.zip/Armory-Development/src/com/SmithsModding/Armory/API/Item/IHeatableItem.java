package com.SmithsModding.Armory.API.Item;

/**
 * Created by Orion
 * Created on 02.05.2015
 * 15:04
 * <p/>
 * Copyrighted according to Project specific license
 */
public interface IHeatableItem extends IResourceContainer {
    String getInternalType();
}
