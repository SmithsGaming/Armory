package com.SmithsModding.Armory.API.Events.Common;
/*
*   RegisterModifiersEvent
*   Created by: Orion
*   Created on: 8-4-2014
*/

import cpw.mods.fml.common.eventhandler.Event;

public class RegisterModifiersEvent extends Event {
    public RegisterModifiersEvent() {
        super();
    }
}
