/*
 * Copyright (c) 2015.
 *
 * Copyrighted by SmithsModding according to the project License
 */

package com.SmithsModding.Armory.API.Events.Common;

import cpw.mods.fml.common.eventhandler.Event;

public class RegisterKnowledgeEvent extends Event {

    public RegisterKnowledgeEvent() {
        super();
    }
}
