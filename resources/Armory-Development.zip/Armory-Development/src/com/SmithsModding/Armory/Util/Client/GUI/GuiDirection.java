package com.SmithsModding.Armory.Util.Client.GUI;

/**
 * Created by Orion
 * Created on 11.05.2015
 * 11:49
 * <p/>
 * Copyrighted according to Project specific license
 */
public enum GuiDirection {
    HORIZONTAL,
    VERTICAL
}
