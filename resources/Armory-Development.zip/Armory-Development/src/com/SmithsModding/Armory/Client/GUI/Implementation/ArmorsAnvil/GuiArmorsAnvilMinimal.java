package com.SmithsModding.Armory.Client.GUI.Implementation.ArmorsAnvil;

import com.SmithsModding.Armory.Client.GUI.ArmoryBaseGui;
import com.SmithsModding.Armory.Client.GUI.Components.*;
import com.SmithsModding.Armory.Client.GUI.Components.Ledgers.InfoLedger;
import com.SmithsModding.Armory.Client.GUI.Components.MultiComponents.ComponentAnvilCraftingGrid;
import com.SmithsModding.Armory.Client.GUI.Components.MultiComponents.ComponentPlayerInventory;
import com.SmithsModding.Armory.Common.Registry.GeneralRegistry;
import com.SmithsModding.Armory.Common.TileEntity.Anvil.TileEntityArmorsAnvil;
import com.SmithsModding.Armory.Network.Messages.MessageCustomInput;
import com.SmithsModding.Armory.Network.NetworkManager;
import com.SmithsModding.Armory.Util.Client.Colors;
import com.SmithsModding.Armory.Util.Client.Textures;
import com.SmithsModding.Armory.Util.Client.TranslationKeys;
import com.SmithsModding.Armory.Util.References;
import net.minecraft.client.Minecraft;
import net.minecraft.inventory.Container;
import org.lwjgl.input.Keyboard;

/**
 * Created by Orion
 * Created on 15.05.2015
 * 12:35
 * <p/>
 * Copyrighted according to Project specific license
 */
public class GuiArmorsAnvilMinimal extends ArmoryBaseGui {
    public GuiArmorsAnvilMinimal(Container pTargetedContainer) {
        super(pTargetedContainer);

        this.xSize = 215;
        this.ySize = 255;

    }

    @Override
    public void initGui() {
        super.initGui();
        Keyboard.enableRepeatEvents(true);

        if (iComponents.getComponents().size() > 0) {
            return;
        }

        iComponents.addComponent(new ComponentBorder(this, References.InternalNames.GUIComponents.Anvil.BACKGROUND, 0, 0, xSize, ySize - 80, Colors.DEFAULT, ComponentBorder.CornerTypes.Inwarts));
        iComponents.addComponent(new ComponentPlayerInventory(this, References.InternalNames.GUIComponents.Anvil.PLAYERINVENTORY, 20, 172, (29), ComponentBorder.CornerTypes.Outwarts));
        iComponents.addComponent(new ComponentAnvilCraftingGrid(this, References.InternalNames.GUIComponents.Anvil.EXTENDEDCRAFTING, 10, 51, 0, TileEntityArmorsAnvil.MAX_CRAFTINGSLOTS, Colors.DEFAULT, Colors.DEFAULT));
        iComponents.addComponent(new ComponentBorder(this, References.InternalNames.GUIComponents.Anvil.SMITHINGSGUIDEBORDER, 178, 51, 30, 30, Colors.DEFAULT, ComponentBorder.CornerTypes.Inwarts));
        iComponents.addComponent(new ComponentBorder(this, References.InternalNames.GUIComponents.Anvil.TEXTBOXBORDER, 61, 7, 111, 30, Colors.DEFAULT, ComponentBorder.CornerTypes.Inwarts));
        iComponents.addComponent(new ComponentBorder(this, References.InternalNames.GUIComponents.Anvil.TOOLSLOTBORDER, 178, 103, 30, 52, Colors.DEFAULT, ComponentBorder.CornerTypes.Inwarts));
        iComponents.addComponent(new ComponentSlot(this, References.InternalNames.GUIComponents.Anvil.HAMMERSLOT, TileEntityArmorsAnvil.MAX_CRAFTINGSLOTS + TileEntityArmorsAnvil.MAX_OUTPUTSLOTS, 18, 18, 184, 109, Textures.Gui.Anvil.HAMMERSLOT, Colors.DEFAULT));
        iComponents.addComponent(new ComponentSlot(this, References.InternalNames.GUIComponents.Anvil.TONGSLOT, TileEntityArmorsAnvil.MAX_CRAFTINGSLOTS + TileEntityArmorsAnvil.MAX_OUTPUTSLOTS + TileEntityArmorsAnvil.MAX_HAMMERSLOTS, 18, 18, 184, 131, Textures.Gui.Anvil.TONGSSLOT, Colors.DEFAULT));
        iComponents.addComponent(new ComponentImage(this, References.InternalNames.GUIComponents.Anvil.LOGO, 17, 7, Textures.Gui.Anvil.HAMMER));
        iComponents.addComponent(new ComponentSlot(this, References.InternalNames.GUIComponents.Anvil.SMITHINGSGUIDESLOT, TileEntityArmorsAnvil.MAX_CRAFTINGSLOTS + TileEntityArmorsAnvil.MAX_OUTPUTSLOTS + TileEntityArmorsAnvil.MAX_HAMMERSLOTS + TileEntityArmorsAnvil.MAX_TONGSLOTS + TileEntityArmorsAnvil.MAX_ADDITIONALSLOTS + TileEntityArmorsAnvil.MAX_COOLSLOTS, 18, 18, 184, 57, Textures.Gui.Basic.Slots.DEFAULT, Colors.DEFAULT, Textures.Gui.Anvil.BOOKSLOT));
        iComponents.addComponent(new ComponentExperienceLabel(this, References.InternalNames.GUIComponents.Anvil.EXPERIENCELABEL, 115, 78, 0, 0));
        iComponents.addComponent(new ComponentTextbox(this, References.InternalNames.GUIComponents.Anvil.TEXTBOX, Minecraft.getMinecraft().fontRenderer, 65, 11, 102, 22, References.InternalNames.InputHandlers.Anvil.ITEMNAME));

        getLedgerManager().addLedgerLeft(new InfoLedger(this, TranslationKeys.GUI.InformationTitel, new String[]{TranslationKeys.GUI.Anvil.InfoLine1, "", TranslationKeys.GUI.Anvil.InfoLine2}, Textures.Gui.Basic.INFOICON.getIcon()));

        NetworkManager.INSTANCE.sendToServer(new MessageCustomInput(References.InternalNames.InputHandlers.Anvil.PLAYEROPENGUI, Minecraft.getMinecraft().thePlayer.getGameProfile().getId().toString()));
    }

    /**
     * Called when the screen is unloaded. Used to disable keyboard repeat events
     */
    public void onGuiClosed() {
        super.onGuiClosed();
        Keyboard.enableRepeatEvents(false);
        try {
            NetworkManager.INSTANCE.sendToServer(new MessageCustomInput(References.InternalNames.InputHandlers.Anvil.PLAYERCLOSEGUI, Minecraft.getMinecraft().thePlayer.getGameProfile().getId().toString()
            ));
        } catch (Exception pEx) {
            GeneralRegistry.iLogger.info("The connection to the server seems to have been aborted. Could not notify the server of closing the Anvil Screen.");
        }
    }
}
